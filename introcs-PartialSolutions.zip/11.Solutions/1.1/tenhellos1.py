#-----------------------------------------------------------------------
# tenhellos1.py
#-----------------------------------------------------------------------

import stdio

# Hello, World 메시지를 표준 출력 장치에 10번 출력한다.

stdio.writeln('Hello, World')
stdio.writeln('Hello, World')
stdio.writeln('Hello, World')
stdio.writeln('Hello, World')
stdio.writeln('Hello, World')
stdio.writeln('Hello, World')
stdio.writeln('Hello, World')
stdio.writeln('Hello, World')
stdio.writeln('Hello, World')
stdio.writeln('Hello, World')

#-----------------------------------------------------------------------

# python tenhellos1.py
# Hello, World
# Hello, World
# Hello, World
# Hello, World
# Hello, World
# Hello, World
# Hello, World
# Hello, World
# Hello, World
# Hello, World

