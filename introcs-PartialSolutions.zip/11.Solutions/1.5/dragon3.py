#-----------------------------------------------------------------------
# dragon3.py
#-----------------------------------------------------------------------

import stdio

dragon = stdio.readString()
nogard = stdio.readString()

stdio.write(dragon + 'L' + nogard)
stdio.write(' ')
stdio.write(dragon + 'R' + nogard)
stdio.writeln()

#-----------------------------------------------------------------------

# python dragon3.py < input.txt | python dragon3.py | python dragon3.py
# FLFLFRFLFLFRFRF FLFLFRFRFLFRFRF

